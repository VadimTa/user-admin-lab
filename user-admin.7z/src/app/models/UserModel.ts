export class UserModel
{
    id: number;
    username: string;
    email: string;
    info:  UserInfo;
}
export class UserInfo
{
    firstName: string;
      lastName: string;
      jobTitle: string;
      avatar: string;
      phoneNumber: string;
}
