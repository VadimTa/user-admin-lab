import { Component, OnInit } from '@angular/core';
import { UserModel, UserInfo } from 'src/app/models/UserModel';

@Component({
  selector: 'app-user-container',
  templateUrl: './user-container.component.html',
  styleUrls: ['./user-container.component.css']
})
export class UserContainerComponent implements OnInit {

  currentUser : UserModel;
  constructor() {

   }

  ngOnInit(): void {
  this.currentUser = new UserModel();
  this.currentUser.email="aaa@aaa.aaa";
  this.currentUser.username="aaa";
  this.currentUser.id=1;
  this.currentUser.info = new UserInfo();
  this.currentUser.info.avatar="a";
  this.currentUser.info.firstName="aaa";
  this.currentUser.info.jobTitle="jjj";
  this.currentUser.info.lastName="bbb";
  this.currentUser.info.phoneNumber="1234";

  }
  Update(username:string, email:string)
  {
    this.currentUser.email=email;
    this.currentUser.username=username;
  }

}
